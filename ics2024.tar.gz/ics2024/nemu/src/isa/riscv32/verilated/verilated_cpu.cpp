#include "./vsrc/obj_dir/Vcpu.h"
#include <cstdio>
#include <assert.h>
#include <fstream>
#include <iostream>
using namespace std;

Vcpu* vcpu = NULL;
VerilatedContext* vcontext = NULL;
extern "C" {
    void vcpu_init() {
        if (vcpu) delete vcpu;
        if (vcontext) delete vcontext;
        vcontext = new VerilatedContext();
        vcpu = new Vcpu{vcontext};
        vcpu->clk = 0;
        vcpu->eval();
    }

    void vcpu_do_cycle() {
        vcpu->clk = 1;
        vcpu->eval();
        vcpu->clk = 0;
        vcpu->eval();
    }
}