#include <klib-macros.h>
#include <am.h>

double __muldf3 (double a, double b) { panic("Not implement"); }
long __fixdfdi (double a) { panic("Not implement"); }
