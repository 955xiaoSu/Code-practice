// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vexample_DoubleControlSwitch.h for the primary calling header

#include "Vexample_DoubleControlSwitch__pch.h"
#include "Vexample_DoubleControlSwitch__Syms.h"
#include "Vexample_DoubleControlSwitch___024root.h"

void Vexample_DoubleControlSwitch___024root___ctor_var_reset(Vexample_DoubleControlSwitch___024root* vlSelf);

Vexample_DoubleControlSwitch___024root::Vexample_DoubleControlSwitch___024root(Vexample_DoubleControlSwitch__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vexample_DoubleControlSwitch___024root___ctor_var_reset(this);
}

void Vexample_DoubleControlSwitch___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

Vexample_DoubleControlSwitch___024root::~Vexample_DoubleControlSwitch___024root() {
}
