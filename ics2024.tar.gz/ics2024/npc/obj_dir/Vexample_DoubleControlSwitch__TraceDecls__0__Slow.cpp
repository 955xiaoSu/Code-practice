// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vexample_DoubleControlSwitch___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vexample_DoubleControlSwitch___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vexample_DoubleControlSwitch___024root__traceDeclTypesSub0(tracep);
}
