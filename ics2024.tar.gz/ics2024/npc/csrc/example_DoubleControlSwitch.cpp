#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "Vexample_DoubleControlSwitch.h"
#include "verilated.h"
#include "verilated_vcd_c.h"

int main (int argc, char **argv) {
    VerilatedContext *contextp = new VerilatedContext;
    contextp->commandArgs(argc, argv);
    Vexample_DoubleControlSwitch* DoubleControlSwitch = new 
        Vexample_DoubleControlSwitch(contextp);
    
    VerilatedVcdC* tfp = new VerilatedVcdC;
    contextp->traceEverOn(true);
    DoubleControlSwitch->trace(tfp, 0);
    tfp->open("./obj_dir/example_DoubleControlSwitch.vcd");

    while (!contextp->gotFinish()) {
        int a = rand() & 1;
        int b = rand() & 1;
        DoubleControlSwitch->a = a;
        DoubleControlSwitch->b = b;
        DoubleControlSwitch->eval();
        printf("a=%d, b=%d, f=%d\n", a, b, DoubleControlSwitch->f);

        tfp->dump(contextp->time());
        contextp->timeInc(1);        

        assert(DoubleControlSwitch->f == (a ^ b));
    }
   
    delete DoubleControlSwitch;
    tfp->close();
    delete contextp;
    return 0;
}