#include <stdio.h>

int main() {
  printf("Hello, ysyx!\n");
  return 0;
}
