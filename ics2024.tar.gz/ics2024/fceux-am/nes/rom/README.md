Put rom files under this directory and rename them to `xxx.nes`.
