#include <am.h>

#define MKK(k) AM_KEY_##k
#define MKK_COUNT 256
