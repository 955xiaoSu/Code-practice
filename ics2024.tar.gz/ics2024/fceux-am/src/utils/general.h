
extern uint32 uppow2(uint32 n);

